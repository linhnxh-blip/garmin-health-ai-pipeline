# 🩺 Báo cáo Phân tích Sinh lý học & Phục hồi Toàn diện (Chủ Nhật, 20/09/2026)

===SECTION_BREAK===
### 🧠 1. Trạng thái Thần kinh Thực vật & Hô hấp Đêm:
- **Cân bằng Thần kinh Thực vật (HRV Overnight vs Baseline Toàn Lịch sử):** 
  Chỉ số biến thiên nhịp tim đêm nay ghi nhận **47.0 ms**, nằm trong trạng thái **Cân bằng (BALANCED)**. So với mức trung bình baseline 30 ngày (40.53 ms, Std: 7.73 ms), HRV đêm nay **tăng cao hơn +15.96% (+6.47 ms)**. Tốc độ phục hồi của hệ thần kinh phó giao cảm (Parasympathetic Nervous System) duy trì ở mức xuất sắc, vượt xa ngưỡng cảnh báo mệt mỏi thần kinh tích lũy (32.8 ms). Xu hướng HRV 7 ngày gần nhất tiếp tục đi lên, phản ánh sự thích nghi sinh học tích cực của cơ thể trong chu kỳ hạ tải / chuẩn bị rơi vào điểm rơi phong độ.
- **Nhịp tim nghỉ & Mức độ Stress (RHR & Stress Deviation):** 
  Nhịp tim nghỉ đêm qua đạt **59 bpm**, chỉ chênh lệch nhẹ **+0.57 bpm** so với baseline 30 ngày (58.43 bpm). Mức độ Stress trung bình trong ngày chạm ngưỡng rất thấp: **16/100** (Max: 54). RHR không tăng vọt (dưới mức lệch chuẩn cảnh báo Baseline + 2 bpm = 60.43 bpm) kết hợp với HRV ở mức cao chứng minh rằng mặc dù có áp lực tiêu hóa muộn từ bữa lẩu tối qua, hệ thần kinh tự chủ và hệ thống tim mạch của bạn vẫn kiểm soát và chuyển hóa năng lượng cực kỳ hiệu quả mà không bị rơi vào trạng thái quá tải giao cảm (Sympathetic Overload).
- **Sinh lý Hô hấp & Nồng độ Oxy SpO2 Đêm:** 
  Nhịp thở trung bình khi ngủ đạt **15.0 brpm** (dao động từ 10.0 brpm đến 23.0 brpm), nằm hoàn toàn trong biên độ sinh lý khỏe mạnh. Nồng độ oxy trong máu SpO2 trung bình đêm đạt **93.0 %**, tuy nhiên ghi nhận mức giảm chớp nhoáng xuống **79.0 %** (Min). Hiện tượng tụt oxy mô cục bộ này thường xuất hiện khi cơ thể trải qua các cơn sụt giảm áp lực đường thở tạm thời do tư thế nằm ngủ ngửa (supine position) hoặc áp lực cơ hoành gia tăng do dạ dày chưa tiêu hóa hết thức ăn từ bữa ăn muộn.
- **Cân nặng & Thể trạng OMRON VIVA / Garmin:** 
  - Cân nặng thực tế: **64.7 kg**.
  - Tỷ lệ % Mỡ cơ thể (Body Fat %): **16.9 %**.
  - Tỷ lệ % Cơ xương (Muscle Mass %): **37.5 %**.
  - Mỡ nội tạng (Visceral Fat): **Mức 6** (An toàn, tối ưu).
  - Độ lệch nhiệt độ da (Skin Temp Deviation): **Chưa đo lường được (NULL)**.
  *Đánh giá:* Chỉ số thể trạng 64.7 kg là mức cân nặng lý tưởng cho hình thái vận động viên đường dài. Tỷ lệ mỡ 16.9% kết hợp khối lượng cơ xương 37.5% mang lại **Tỷ lệ công suất trên trọng lượng cơ thể (Power-to-Weight Ratio)** tối ưu, giảm thiểu lực tác động chấn thương lên gân khớp thân dưới trong các bước chạy dài.

===SECTION_BREAK===
### 💤 2. Bóc tách Cấu trúc Giấc ngủ & Tái tạo Sinh học:
- **Phân bổ Các Giai đoạn Giấc ngủ (Sleep Architecture):** 
  Tổng thời gian ngủ đêm qua chỉ đạt **6 giờ 01 phút** (Điểm số giấc ngủ: **62/100**). Cấu trúc chi tiết:
  + **Ngủ sâu (Deep Sleep): 42 phút (chiếm 11.6%)** - Thấp hơn ngưỡng tiêu chuẩn tối thiểu (15-20%). Đây là giai đoạn tuyến yên tiết ra Hormone Tăng trưởng (HGH) để tái tạo sợi cơ bị tổn thương và tổng hợp glycogen.
  + **Ngủ mơ (REM Sleep): 18 phút (chiếm 5.0%)** - Thấp hơn nghiêm trọng so với mức tiêu chuẩn 20-25%. REM là giai đoạn phục hồi hệ thần kinh trung ương, củng cố trí nhớ vận động (motor memory) và điều hòa cảm xúc.
  + **Ngủ nông (Light Sleep): 5 giờ 01 phút (chiếm 83.4%)** - Tỷ lệ ngủ nông quá cao.
  + **Thời gian thức giấc (Awake): 7 phút**.
- **Hiệu suất Sạc Body Battery & Trí nhớ Động (Adaptive Memory):** 
  Đêm qua ghi nhận mức sạc **Body Battery +42 điểm** (đạt đỉnh **71/100** từ mức đáy 29/100). Dựa trên mô hình Trí nhớ Động cá nhân tích lũy 61 ngày (mỗi 15 phút Deep Sleep đóng góp trung bình +3.5 điểm Body Battery), 42 phút Deep Sleep đóng góp khoảng **+9.8 điểm**. Phần năng lượng sạc còn lại (+32.2 điểm) đến từ giai đoạn Light Sleep nhờ mức độ Stress đêm rất thấp (16/100).
- **Phân tích Nguyên nhân Sinh lý từ Nhật ký Dinh dưỡng Hôm qua:** 
  Nhật ký ghi nhận bữa ăn lẩu bò kéo dài tới **21:00 (19/09)**, chỉ cách thời gian đi ngủ (21:30) khoảng **30 phút**. 
  *Cơ chế sinh lý học:* Mặc dù cồn không xuất hiện (0.0 đơn vị) và HRV vẫn duy trì ở mức cao (47 ms) nhờ hệ thần kinh thực vật thích nghi tốt, nhưng khối lượng protein, mỡ và natri dồn nén lúc 21:00 buộc hệ tiêu hóa phải hoạt động liên tục. Việc dạ dày căng nồng năng lượng làm tăng nhẹ chuyển hóa nội tạng, khiến bộ não trì hoãn việc tiến sâu vào giai đoạn REM và Deep Sleep, chuyển phần lớn thời lượng giấc ngủ thành Light Sleep (5h 01m).

===SECTION_BREAK===
### 🏃‍♂️ 3. Kê đơn Vận động & Tải Tập luyện Hôm nay:
- **Bối cảnh Microcycle & Dynamic Tapering:** 
  - Sự kiện mục tiêu: **Hanoi Full Marathon (42.195km)** - Ngày 04/10/2026.
  - Đếm ngược: **Còn đúng 14 ngày** (Chính thức bước vào **Pha Hạ tải Đầu tiên / Early Tapering Phase**).
  - Điểm sẵn sàng tập luyện (Training Readiness): **66/100 (Khá tốt)**.
  - Thời gian phục hồi còn lại (Recovery Time): **1 giờ**.
  - Trạng thái tập luyện (Training Status): **Giảm thể lực (Detraining)** (Mã Garmin gốc: `DETRAINING`). 
    *Diễn giải sinh lý:* Trạng thái "Giảm thể lực" xuất hiện do tổng tải tập luyện 7 ngày giảm xuống (2 bài tập, 3h 34m), đây là phản ứng hoàn toàn tự nhiên và đúng chiến thuật khi bắt đầu chu kỳ Tapering nhằm xả toàn bộ mệt mỏi tích tụ (Fatigue Drop) để chuẩn bị bùng nổ thể lực (Fitness Peak) vào ngày thi đấu.
- **Kê đơn Bài tập Chi tiết cho Chủ Nhật (20/09/2026):** 
  - **Mục tiêu:** Nghỉ ngơi hoàn toàn (Rest Day) / Phục hồi chủ động (Active Recovery).
  - **Chỉ định:** KHÔNG chạy bộ, KHÔNG tập Gym nặng hôm nay để ưu tiên bù đắp thiếu hụt giấc ngủ và tích lũy Glycogen.
  - **Hoạt động gợi ý (Tùy chọn nhẹ):** 
    + Đi bộ thư giãn nhẹ nhàng 15 - 20 phút vào buổi chiều (trước 17:30) để kích hoạt tuần hoàn máu.
    + Nhịp tim mục tiêu nếu đi bộ: Zone 1 / MAF phục hồi (dưới 110 bpm). Ngưỡng nhịp tim hiếu khí tối đa MAF Zone 2 của bạn là `(180 - 44 = 136 bpm)`.
- **Phân tích Động học Chạy bộ HRM-Pro (Chế độ Trí nhớ Động):** 
  Dữ liệu động học chạy bộ gần nhất ghi nhận:
  - **Nhịp chân (Cadence):** **172.9 spm** (Mức guồng chân tối ưu, hạn chế áp lực dồn vào khớp gối).
  - **Cân bằng thời gian tiếp đất (GCT Balance L/R):** **50.65% Chân Trái / 49.35% Chân Phải**.
  *Cảnh báo sinh lý:* Độ lệch cân bằng tiếp đất lệch về chân trái **1.3%** (vượt ngưỡng an toàn 1.0%). Sự bất đối xứng này cho thấy chân trái đang chịu lực hạ cánh và phát lực đẩy nhiều hơn chân phải. Cần chú ý thực hiện các bài giãn cơ gân kheo, cơ mông bé và lăn bọt foam roller cho chân trái trong các ngày nghỉ để tránh nguy cơ quá tải gân Achilles trái trước ngày thi đấu.

===SECTION_BREAK===
### 🍱 4. Kế hoạch Dinh dưỡng & Thực đơn Cá nhân hóa (Precision Nutrition):
- **Trạng thái Chiến lược Dinh dưỡng:** 
  Hiện tại còn **14 ngày** đến giải chạy (`days_to_race = 14`), CHƯA kích hoạt chế độ nạp Carb cấp tập (Carbo-loading Phase - chỉ tự động kích hoạt khi còn <= 3 ngày). Hôm nay áp dụng chế độ **Precision Recovery & Tapering Nutrition**.
- **Tính toán Macro Mục tiêu theo Cân nặng Thực tế (64.7 kg):** 
  - **Protein mục tiêu:** `1.9g x 64.7 kg = 122.9g Protein/ngày`.
  - **Tổng Năng lượng Mục tiêu:** khoảng **2,100 - 2,200 kcal** (phù hợp cho ngày nghỉ phục hồi).
  - **Tỷ lệ Phân bổ Macro:** Carbohydrate 50% (~265g) | Protein 25% (~123g) | Fat 25% (~60g).
- **TỔNG NẠP THỰC TẾ HÔM QUA & HƯỚNG DẪN BÙ TRỪ HÔM NAY:** 
  - Tổng thực tế hôm qua: ~850 kcal | Protein: 55.0g | Carb: 65.0g | Fat: 35.0g.
  *Đánh giá thâm hụt:* Ngày hôm qua bạn bị thâm hụt năng lượng và đạm rất nghiêm trọng (thiếu tới ~67.9g Protein và hơn 1,250 kcal so với nhu cầu phục hồi cơ bắp).
  - **HƯỚNG DẪN BÙ TRỪ CỤ THỂ HÔM NAY:** Do ngày hôm qua nạp thiếu 67.9g Protein và khoảng 1,250 kcal so với mục tiêu, hôm nay hãy bổ sung thêm 180g thịt bò thăn áp chảo vào bữa trưa và 1 hũ sữa chua Hy Lạp Chobani cùng 30g hạt hạnh nhân vào bữa phụ chiều để bù đắp thâm hụt năng lượng nghiêm trọng và tái cấu trúc sợi cơ bị tổn thương.
- **Thực đơn Chi tiết Gợi ý Từng Bữa trong Ngày:**
  - **Bữa sáng (06:30 - 07:00):** Bữa ăn phục hồi vi chất & Glycogen nhẹ nhàng.
    + 1 hũ Sữa chua Hy Lạp Chobani (hoặc sữa chua không đường tương đương).
    + 1 quả chuối chín + 40g yến mạch cán vỡ ngâm sữa tươi ít bệt.
    + 1 thìa mật ong nguyên chất (15ml).
    + *Macros:* ~420 kcal | Protein: 22g | Carb: 65g | Fat: 8g.
  - **Bữa trưa (11:30 - 12:30):** Bữa ăn chính bù đắp thâm hụt đạm và năng lượng.
    + 2 chén cơm trắng hoặc cơm gạo lứt (~250g).
    + 180g - 200g Thịt bò thăn áp chảo / xào ớt chuông với dầu olive.
    + 1 đĩa lớn rau đĩa xanh luộc (Súp lơ xanh, bắp cải).
    + 1 đĩa kim chi nhỏ kích thích vi sinh đường ruột.
    + *Macros:* ~780 kcal | Protein: 52g | Carb: 80g | Fat: 22g.
  - **Bữa phụ chiều (15:30 - 16:00):**
    + 1 hũ Sữa chua Hy Lạp Chobani + 30g hạt hạnh nhân hoặc hạt óc chó.
    + 1 ly nước ép táo hoặc cam tươi (200ml).
    + *Macros:* ~320 kcal | Protein: 18g | Carb: 35g | Fat: 12g.
  - **Bữa tối (BẮT BUỘC KẾT THÚC TRƯỚC 18:30 - 19:00):** Nghiêm ngặt kết thúc trước 18:30 để hoàn tất tiêu hóa trước 21:00.
    + 180g Cá hồi áp chảo hoặc Đĩa Sashimi cá hồi / cá ngừ tươi thanh sạch.
    + 1 chén cơm trắng nhỏ (~120g).
    + 1 bát canh rau cải cúc hoặc rau ngót nấu thịt băm thanh nhẹ (ít mỡ).
    + *Macros:* ~580 kcal | Protein: 38g | Carb: 45g | Fat: 18g.
  - **Bổ sung Vi chất & Bù Nước Buổi tối (20:30 - 21:00):**
    + **Bổ sung Nước:** Nạp đủ **3.0 Lít nước khoáng kiềm Fujiwa** rải đều trong cả ngày (chia nhỏ 200ml mỗi giờ, ngưng uống nhiều sau 20:30 để tránh thức giấc tiểu đêm).
    + **Vi chất trước khi ngủ:** Uống 1 liều **Magie Bisglycinate (300mg - 400mg)** vào lúc 20:45 (30 phút trước khi ngủ). Magie dạng Bisglycinate giúp thư giãn cơ tim, hạ áp lực thần kinh và tăng đáng kể thời lượng Deep Sleep & REM đêm nay. Đi ngủ đúng **21:30**.